--
-- PostgreSQL database dump
--

\restrict eb7qzUTimnXgfepXHrp0vGOa4BKWw18hWtz4HUKpg8h9IzMXckmuz3jD9eWJwzm

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    user_id integer,
    action text NOT NULL,
    entity_type text,
    entity_id integer,
    details text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.activity_logs OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    visitor_name text NOT NULL,
    visitor_tc text,
    visitor_phone text,
    visitor_email text,
    visitor_company text,
    vehicle_plate text,
    visitor_count integer DEFAULT 1 NOT NULL,
    host_personnel_id integer,
    host_user_id integer,
    reason text,
    notes text,
    planned_time timestamp with time zone NOT NULL,
    status text DEFAULT 'planned'::text NOT NULL,
    visitor_id integer,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: blacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blacklist (
    id integer NOT NULL,
    full_name text NOT NULL,
    tc_no text,
    company text,
    reason text,
    added_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.blacklist OWNER TO postgres;

--
-- Name: blacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blacklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blacklist_id_seq OWNER TO postgres;

--
-- Name: blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blacklist_id_seq OWNED BY public.blacklist.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    logo_path text,
    theme_color text DEFAULT '#1a56db'::text,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.companies_id_seq OWNER TO postgres;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: contents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contents (
    id integer NOT NULL,
    company_id integer,
    type text NOT NULL,
    file_path text,
    title text,
    content_text text,
    display_order integer DEFAULT 0 NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.contents OWNER TO postgres;

--
-- Name: contents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contents_id_seq OWNER TO postgres;

--
-- Name: contents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contents_id_seq OWNED BY public.contents.id;


--
-- Name: personnel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personnel (
    id integer NOT NULL,
    company_id integer,
    full_name text NOT NULL,
    title text,
    department text,
    phone text,
    email text,
    user_id integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.personnel OWNER TO postgres;

--
-- Name: personnel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personnel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personnel_id_seq OWNER TO postgres;

--
-- Name: personnel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personnel_id_seq OWNED BY public.personnel.id;


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.push_subscriptions (
    id integer NOT NULL,
    user_id integer,
    subscription text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.push_subscriptions OWNER TO postgres;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.push_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.push_subscriptions_id_seq OWNER TO postgres;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.push_subscriptions_id_seq OWNED BY public.push_subscriptions.id;


--
-- Name: room_reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room_reservations (
    id integer NOT NULL,
    room_id integer NOT NULL,
    user_id integer,
    title text NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.room_reservations OWNER TO postgres;

--
-- Name: room_reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.room_reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_reservations_id_seq OWNER TO postgres;

--
-- Name: room_reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.room_reservations_id_seq OWNED BY public.room_reservations.id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    name text NOT NULL,
    capacity integer DEFAULT 10 NOT NULL,
    floor text,
    equipment text,
    status text DEFAULT 'available'::text NOT NULL,
    current_visitor_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rooms_id_seq OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_id_seq OWNED BY public.rooms.id;


--
-- Name: screen_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.screen_logs (
    id integer NOT NULL,
    visitor_id integer,
    content_id integer,
    action text,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    duration_seconds integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.screen_logs OWNER TO postgres;

--
-- Name: screen_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.screen_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.screen_logs_id_seq OWNER TO postgres;

--
-- Name: screen_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.screen_logs_id_seq OWNED BY public.screen_logs.id;


--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_logs (
    id integer NOT NULL,
    level text DEFAULT 'info'::text NOT NULL,
    module text,
    message text NOT NULL,
    details text,
    user_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.system_logs OWNER TO postgres;

--
-- Name: system_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_logs_id_seq OWNER TO postgres;

--
-- Name: system_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_logs_id_seq OWNED BY public.system_logs.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key text NOT NULL,
    value text,
    label text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO postgres;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    full_name text NOT NULL,
    role text NOT NULL,
    department text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: visitors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.visitors (
    id integer NOT NULL,
    full_name text NOT NULL,
    tc_no text,
    phone text,
    email text,
    company_name text,
    vehicle_plate text,
    visitor_count integer DEFAULT 1 NOT NULL,
    host_personnel_id integer,
    host_user_id integer,
    reason text,
    notes text,
    status text DEFAULT 'waiting'::text NOT NULL,
    is_approved boolean DEFAULT false NOT NULL,
    is_screen_active boolean DEFAULT false NOT NULL,
    planned_time timestamp with time zone,
    arrival_time timestamp with time zone,
    checkout_time timestamp with time zone,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.visitors OWNER TO postgres;

--
-- Name: visitors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.visitors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.visitors_id_seq OWNER TO postgres;

--
-- Name: visitors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.visitors_id_seq OWNED BY public.visitors.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: blacklist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blacklist ALTER COLUMN id SET DEFAULT nextval('public.blacklist_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: contents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contents ALTER COLUMN id SET DEFAULT nextval('public.contents_id_seq'::regclass);


--
-- Name: personnel id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnel ALTER COLUMN id SET DEFAULT nextval('public.personnel_id_seq'::regclass);


--
-- Name: push_subscriptions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.push_subscriptions_id_seq'::regclass);


--
-- Name: room_reservations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_reservations ALTER COLUMN id SET DEFAULT nextval('public.room_reservations_id_seq'::regclass);


--
-- Name: rooms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN id SET DEFAULT nextval('public.rooms_id_seq'::regclass);


--
-- Name: screen_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.screen_logs ALTER COLUMN id SET DEFAULT nextval('public.screen_logs_id_seq'::regclass);


--
-- Name: system_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_logs ALTER COLUMN id SET DEFAULT nextval('public.system_logs_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: visitors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visitors ALTER COLUMN id SET DEFAULT nextval('public.visitors_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_logs (id, user_id, action, entity_type, entity_id, details, created_at) FROM stdin;
1	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-13 12:30:38.681+03
2	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-13 12:39:48.846+03
3	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-13 19:00:55.046+03
4	2	login	user	\N	Burcu Öktem giriş yaptı	2026-04-13 19:05:45.947+03
5	3	login	user	\N	Yusuf Karaman giriş yaptı	2026-04-13 19:07:09.229+03
6	4	login	user	\N	Aygerim Bıkmaz giriş yaptı	2026-04-13 19:07:26.527+03
7	2	login	user	\N	Burcu Öktem giriş yaptı	2026-04-13 19:40:14.288+03
8	4	login	user	\N	Aygerim Bıkmaz giriş yaptı	2026-04-13 19:50:48.508+03
9	3	login	user	\N	Yusuf Karaman giriş yaptı	2026-04-13 19:51:04.945+03
10	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-13 19:51:52.998+03
11	2	password_change	user	\N	Burcu Öktem şifresini değiştirdi	2026-04-13 20:14:20.059+03
12	2	logout	user	\N	Burcu Öktem çıkış yaptı	2026-04-13 20:14:23.384+03
13	2	login	user	\N	Burcu Öktem giriş yaptı	2026-04-13 20:14:38.727+03
14	2	visitor_created	visitor	1	Yusuf Karaman kaydı oluşturuldu	2026-04-13 20:15:47.487+03
15	3	visitor_approved	visitor	1	Yusuf Karaman onaylandı	2026-04-13 20:16:24.595+03
16	2	visitor_created	visitor	2	Yusuf Karaman kaydı oluşturuldu	2026-04-13 20:35:46.643+03
17	4	login	user	\N	Aygerim Bıkmaz giriş yaptı	2026-04-13 20:36:02.758+03
18	4	visitor_approved	visitor	2	Yusuf Karaman onaylandı	2026-04-13 20:36:27.569+03
19	2	visitor_created	visitor	3	Hilmi Difyeli kaydı oluşturuldu	2026-04-13 21:30:00.055+03
20	3	visitor_approved	visitor	3	Hilmi Difyeli onaylandı	2026-04-13 21:30:08.284+03
21	2	visitor_created	visitor	4	Yusuf Karaman kaydı oluşturuldu	2026-04-13 21:34:18.603+03
22	4	visitor_approved	visitor	4	Yusuf Karaman onaylandı	2026-04-13 21:34:22.166+03
23	3	visitor_created	visitor	5	Yusuf Karaman kaydı oluşturuldu	2026-04-13 23:30:38.217+03
24	3	visitor_approved	visitor	5	Yusuf Karaman onaylandı	2026-04-13 23:30:59.887+03
25	2	visitor_created	visitor	6	Selim Karaman kaydı oluşturuldu	2026-04-13 23:31:57.399+03
26	3	visitor_approved	visitor	6	Selim Karaman onaylandı	2026-04-13 23:32:03.743+03
27	2	visitor_created	visitor	7	Yusuf Karaman kaydı oluşturuldu	2026-04-13 23:46:52.584+03
28	4	visitor_approved	visitor	7	Yusuf Karaman onaylandı	2026-04-13 23:46:59.674+03
29	4	visitor_approved	visitor	7	Yusuf Karaman onaylandı	2026-04-13 23:47:02.742+03
30	2	visitor_created	visitor	8	Hilmi Difyeli kaydı oluşturuldu	2026-04-13 23:52:24.55+03
31	4	visitor_approved	visitor	8	Hilmi Difyeli onaylandı	2026-04-13 23:52:28.346+03
32	4	logout	user	\N	Aygerim Bıkmaz çıkış yaptı	2026-04-14 00:32:40.868+03
33	4	login	user	\N	Aygerim Bıkmaz giriş yaptı	2026-04-14 00:32:52.319+03
34	4	login	user	\N	Aygerim Bıkmaz giriş yaptı	2026-04-14 00:39:28.297+03
35	2	visitor_created	visitor	9	Yusuf Karaman kaydı oluşturuldu	2026-04-14 00:50:06.428+03
36	4	visitor_approved	visitor	9	Yusuf Karaman onaylandı	2026-04-14 00:50:10.038+03
37	2	login	user	\N	Burcu Öktem giriş yaptı	2026-04-14 07:07:15.274+03
38	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 07:07:41.676+03
39	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 07:11:10.816+03
40	4	login	user	\N	Aygerim Bıkmaz giriş yaptı	2026-04-14 07:15:49.861+03
41	2	login	user	\N	Burcu Öktem giriş yaptı	2026-04-14 07:25:21.305+03
42	2	visitor_created	visitor	10	Yusuf Karaman kaydı oluşturuldu	2026-04-14 07:25:39.218+03
43	4	login	user	\N	Aygerim Bıkmaz giriş yaptı	2026-04-14 07:25:51.923+03
44	4	visitor_approved	visitor	10	Yusuf Karaman onaylandı	2026-04-14 07:26:00.645+03
45	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 07:36:55.842+03
46	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 07:41:27.892+03
47	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 07:52:24.994+03
48	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 07:52:49.718+03
49	2	login	user	\N	Burcu Öktem giriş yaptı	2026-04-14 07:54:08.223+03
50	3	login	user	\N	Yusuf Karaman giriş yaptı	2026-04-14 07:58:30.984+03
51	2	login	user	\N	Burcu Öktem giriş yaptı	2026-04-14 07:58:54.592+03
52	4	login	user	\N	Aygerim Bıkmaz giriş yaptı	2026-04-14 07:59:22.15+03
53	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 07:59:42.045+03
54	3	login	user	\N	Yusuf Karaman giriş yaptı	2026-04-14 08:11:25.677+03
55	2	visitor_created	visitor	11	Selim Karaman kaydı oluşturuldu	2026-04-14 08:11:34.971+03
56	3	visitor_approved	visitor	11	Selim Karaman onaylandı	2026-04-14 08:12:03.045+03
57	2	visitor_created	visitor	12	Selim Karaman kaydı oluşturuldu	2026-04-14 08:13:53.479+03
58	3	visitor_approved	visitor	12	Selim Karaman onaylandı	2026-04-14 08:14:34.045+03
59	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 08:31:05.491+03
60	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 08:31:59.204+03
61	2	visitor_created	visitor	13	Yusuf Karaman kaydı oluşturuldu	2026-04-14 08:33:01.707+03
62	4	visitor_approved	visitor	13	Yusuf Karaman onaylandı	2026-04-14 08:33:04.847+03
63	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 08:35:38.847+03
64	1	login	user	\N	Sistem Yöneticisi giriş yaptı	2026-04-14 08:44:37.339+03
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (id, visitor_name, visitor_tc, visitor_phone, visitor_email, visitor_company, vehicle_plate, visitor_count, host_personnel_id, host_user_id, reason, notes, planned_time, status, visitor_id, created_by, created_at) FROM stdin;
1	yusuf karaman	\N	\N	\N	Simsoft	\N	1	4	4	Toplantı	\N	2026-04-14 20:47:00+03	cancelled	\N	2	2026-04-13 20:47:33.552+03
3	Hilmi Difyeli	\N	05533442766	\N	Simsoft	\N	1	3	3	Teknik Destek	\N	2026-04-14 03:29:00+03	cancelled	\N	2	2026-04-13 21:29:56.286+03
2	yusuf karaman	\N	05533442766	\N	Simsoft	\N	1	4	4	İş Görüşmesi	\N	2026-04-14 21:29:00+03	cancelled	\N	2	2026-04-13 21:29:21.744+03
4	Selim Karaman	12577108652	05533442766	YusufKaraman68@gmail.com	Aselsan	14 ABC 14	3	3	3	Danışma	test	2026-04-14 06:31:00+03	cancelled	\N	3	2026-04-13 23:31:44.118+03
5	Hilmi Difyeli	\N	05533442766	\N	Simsoft	\N	1	4	4	Toplantı	\N	2026-04-14 16:50:00+03	cancelled	\N	2	2026-04-13 23:50:24.157+03
6	Yusuf Karaman	\N	05533442766	YusufKaraman68@gmail.com	Simsoft	\N	3	4	4	Toplantı	\N	2026-04-14 06:38:00+03	cancelled	\N	4	2026-04-14 00:38:48.034+03
7	Selim Karaman	\N	05533442766	\N	Aselsan	\N	1	3	3	İş Görüşmesi	\N	2026-04-14 11:12:00+03	cancelled	\N	2	2026-04-14 08:13:09.201+03
\.


--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blacklist (id, full_name, tc_no, company, reason, added_by, created_at) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, name, logo_path, theme_color, is_default, is_active, created_at) FROM stdin;
2	BETA	/uploads/BETA.png	#1a56db	f	t	2026-04-13 19:03:30.4+03
3	TETA	/uploads/tetasmmm.png	#1a56db	f	t	2026-04-13 19:03:37.526+03
4	SIMSOFT	/uploads/simsoftlogo.jpg	#1a56db	f	t	2026-04-13 19:03:46.092+03
5	SmartICT	/uploads/smartictlogo-20210609152003.jpg	#1a56db	f	t	2026-04-13 19:03:55.508+03
6	Airobos	/uploads/AIROBOSlogo.png	#1a56db	f	t	2026-04-13 19:04:03.515+03
7	Agrobrain	/uploads/agrobrainlogo.png	#1a56db	f	t	2026-04-13 19:04:13.366+03
8	Avaitech	/uploads/avaitechofficial_logo.jpg	#1a56db	f	t	2026-04-13 19:04:24.735+03
1	BIKMAZ GRUP	/uploads/BıkmazGrup.jpg	#0b3d2e	t	t	2026-04-13 12:27:31.373+03
\.


--
-- Data for Name: contents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contents (id, company_id, type, file_path, title, content_text, display_order, is_default, is_active, created_at) FROM stdin;
12	5	video	/uploads/media-0f7453ae-98d8-4a06-9b82-02eace673262.mp4	smartictvid.mp4	\N	0	f	t	2026-04-14 07:21:49.434+03
15	4	video	/uploads/media-3eb7cec7-54ed-42a4-9ffe-1f122fb501a2.mp4	simsoftvid.mp4	\N	0	f	t	2026-04-14 07:53:00.848+03
16	3	image	/uploads/media-e188b910-3545-463d-befb-f2f16c2a77f7.png	tetasmmm.png	\N	0	f	t	2026-04-14 07:59:51.383+03
17	6	video	/uploads/media-af88b391-8653-455b-86b1-4979064fe3e1.mp4	airobosvid.mp4	\N	0	f	t	2026-04-14 08:00:54.665+03
18	7	image	/uploads/media-730d783f-ebef-4373-9a6b-b1892f622dcf.png	agrobrainlogo.png	\N	0	f	t	2026-04-14 08:29:49.11+03
19	6	image	/uploads/media-11e8a95a-3698-4b65-b3cc-dfd919b50c67.png	AIROBOSlogo.png	\N	0	f	t	2026-04-14 08:29:56.411+03
20	2	image	/uploads/media-ad209213-9dc6-4376-bb08-e27bed16c1c5.png	BETA.png	\N	0	f	t	2026-04-14 08:30:04.137+03
21	8	image	/uploads/media-d71177d4-862a-40b9-96b9-3644fda464d8.jpg	avaitechofficial_logo.jpg	\N	0	f	t	2026-04-14 08:30:11.647+03
22	4	image	/uploads/media-a1ffbea1-7651-401e-820e-63ef8acc454a.jpg	simsoftlogo.jpg	\N	0	f	t	2026-04-14 08:30:30.34+03
23	5	image	/uploads/media-39556e60-0f24-45c8-bf02-280663c54999.jpg	smartictlogo-20210609152003.jpg	\N	0	f	t	2026-04-14 08:30:38.562+03
\.


--
-- Data for Name: personnel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personnel (id, company_id, full_name, title, department, phone, email, user_id, is_active, created_at) FROM stdin;
1	\N	Sistem Yöneticisi	\N	BT	\N	\N	1	t	2026-04-13 12:39:48.932+03
3	3	Yusuf Karaman	\N	\N	\N	\N	3	t	2026-04-13 19:06:20.642+03
4	3	Aygerim Bıkmaz	\N	\N	\N	\N	4	t	2026-04-13 19:06:56.061+03
2	3	Burcu Öktem	\N	\N	\N	\N	2	t	2026-04-13 19:05:33.342+03
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.push_subscriptions (id, user_id, subscription, created_at) FROM stdin;
4	4	{"endpoint":"https://fcm.googleapis.com/fcm/send/fQ2iGRA3Tf0:APA91bEr_mnYC7_wLcwdZW5T413xJUPDqVty54-o7m0EF4Lb8acSz8hfR2urbEIEuPyTUeKLmOm_rV7fNVPv8kkXmONMIipIlL3yqasmsrlOWUvC1w69yvLUaPeDEs-CaweE2-M8G-UH","expirationTime":null,"keys":{"p256dh":"BF1XJjdc-wcDvCkpDgkPCJU9B4iNtkaRCSdmBYS235cVp6LM1o8eWBlgOsqnzkS3SR5tTci7jzJIuS5x7mUmxmg","auth":"rchhKWOVRhXtZ13SVBT9fQ"}}	2026-04-14 08:10:07.064+03
5	3	{"endpoint":"https://fcm.googleapis.com/fcm/send/fQ2iGRA3Tf0:APA91bEr_mnYC7_wLcwdZW5T413xJUPDqVty54-o7m0EF4Lb8acSz8hfR2urbEIEuPyTUeKLmOm_rV7fNVPv8kkXmONMIipIlL3yqasmsrlOWUvC1w69yvLUaPeDEs-CaweE2-M8G-UH","expirationTime":null,"keys":{"p256dh":"BF1XJjdc-wcDvCkpDgkPCJU9B4iNtkaRCSdmBYS235cVp6LM1o8eWBlgOsqnzkS3SR5tTci7jzJIuS5x7mUmxmg","auth":"rchhKWOVRhXtZ13SVBT9fQ"}}	2026-04-14 08:11:25.924+03
\.


--
-- Data for Name: room_reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room_reservations (id, room_id, user_id, title, start_time, end_time, status, created_at) FROM stdin;
1	1	1	Yusuf Karaman	2026-04-14 09:00:00+03	2026-04-14 12:00:00+03	active	2026-04-14 07:53:47.061+03
2	1	4	Burcu Öktem	2026-04-14 12:00:00+03	2026-04-14 14:00:00+03	cancelled	2026-04-14 08:16:27.381+03
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (id, name, capacity, floor, equipment, status, current_visitor_id, created_at) FROM stdin;
1	TESt oda1 	10	10	\N	available	\N	2026-04-14 07:53:26.067+03
\.


--
-- Data for Name: screen_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.screen_logs (id, visitor_id, content_id, action, start_time, end_time, duration_seconds, created_at) FROM stdin;
1	1	\N	welcome_start	2026-04-13 20:16:24.609+03	2026-04-13 20:16:39.219+03	14	2026-04-13 20:16:24.61+03
2	2	\N	welcome_start	2026-04-13 20:36:27.58+03	2026-04-13 20:42:35.03+03	367	2026-04-13 20:36:27.582+03
3	3	\N	welcome_start	2026-04-13 21:30:08.29+03	2026-04-13 21:33:58.517+03	230	2026-04-13 21:30:08.29+03
4	4	\N	welcome_start	2026-04-13 21:34:22.175+03	2026-04-13 23:30:59.845+03	6997	2026-04-13 21:34:22.176+03
5	5	\N	welcome_start	2026-04-13 23:30:59.895+03	2026-04-13 23:32:03.72+03	63	2026-04-13 23:30:59.897+03
6	6	\N	welcome_start	2026-04-13 23:32:03.748+03	2026-04-13 23:34:23.767+03	140	2026-04-13 23:32:03.749+03
7	7	\N	welcome_start	2026-04-13 23:46:59.683+03	2026-04-13 23:47:02.716+03	3	2026-04-13 23:46:59.684+03
8	7	\N	welcome_start	2026-04-13 23:47:02.749+03	2026-04-13 23:48:33.515+03	90	2026-04-13 23:47:02.75+03
9	8	\N	welcome_start	2026-04-13 23:52:28.352+03	2026-04-13 23:52:37.686+03	9	2026-04-13 23:52:28.352+03
10	9	\N	welcome_start	2026-04-14 00:50:10.047+03	2026-04-14 00:50:13.441+03	3	2026-04-14 00:50:10.048+03
11	10	\N	welcome_start	2026-04-14 07:26:00.648+03	2026-04-14 08:00:08.635+03	2047	2026-04-14 07:26:00.648+03
12	11	\N	welcome_start	2026-04-14 08:12:03.049+03	2026-04-14 08:12:28.549+03	25	2026-04-14 08:12:03.049+03
13	12	\N	welcome_start	2026-04-14 08:14:34.048+03	2026-04-14 08:14:59.335+03	25	2026-04-14 08:14:34.048+03
14	13	\N	welcome_start	2026-04-14 08:33:04.849+03	2026-04-14 08:33:40.199+03	35	2026-04-14 08:33:04.849+03
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_logs (id, level, module, message, details, user_id, created_at) FROM stdin;
2	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 12:27:31.216+03
1	info	SYSTEM	Sunucu başlatılıyor...	{"port":"3000"}	\N	2026-04-13 12:27:31.217+03
3	info	SYSTEM	Sunucu başlatılıyor...	{"port":"3000"}	\N	2026-04-13 12:38:12.685+03
4	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 12:38:12.684+03
5	info	SYSTEM	Sunucu başlatılıyor...	{"port":3000}	\N	2026-04-13 14:45:20.397+03
6	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 14:45:20.396+03
7	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 14:46:42.733+03
8	info	SYSTEM	Sunucu başlatılıyor...	{"port":3000}	\N	2026-04-13 14:46:42.734+03
9	info	SYSTEM	Sunucu başlatılıyor...	{"port":3000}	\N	2026-04-13 14:46:49.289+03
10	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 14:46:49.288+03
12	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 18:04:37.833+03
11	info	SYSTEM	Sunucu başlatılıyor...	{"port":3000}	\N	2026-04-13 18:04:37.835+03
13	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 18:11:46.173+03
14	info	SYSTEM	Sunucu başlatılıyor...	{"port":3000}	\N	2026-04-13 18:11:46.176+03
16	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 20:05:11.177+03
15	info	SYSTEM	Sunucu başlatılıyor...	{"port":3000}	\N	2026-04-13 20:05:11.186+03
17	warn	SYSTEM	SCREEN_API_KEY tanimli degil; /api/screen/log gelistirme modunda korumasiz calisacak.	{"route":"/api/screen/log"}	\N	2026-04-13 20:29:31.13+03
18	info	SYSTEM	Sunucu başlatılıyor...	{"port":"3000"}	\N	2026-04-13 20:29:31.13+03
19	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 20:29:31.128+03
20	info	SYSTEM	Sunucu başlatılıyor...	{"port":"3000"}	\N	2026-04-13 21:32:37.853+03
21	warn	SYSTEM	SCREEN_API_KEY tanimli degil; /api/screen/log gelistirme modunda korumasiz calisacak.	{"route":"/api/screen/log"}	\N	2026-04-13 21:32:37.853+03
22	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 21:32:37.85+03
23	info	SYSTEM	Sunucu başlatılıyor...	{"port":"3000"}	\N	2026-04-13 21:36:03.744+03
24	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 21:36:03.742+03
25	warn	SYSTEM	SCREEN_API_KEY tanimli degil; /api/screen/log gelistirme modunda korumasiz calisacak.	{"route":"/api/screen/log"}	\N	2026-04-13 21:36:03.743+03
27	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-13 21:50:44.872+03
26	warn	SYSTEM	SCREEN_API_KEY tanimli degil; /api/screen/log gelistirme modunda korumasiz calisacak.	{"route":"/api/screen/log"}	\N	2026-04-13 21:50:44.879+03
28	info	SYSTEM	Sunucu başlatılıyor...	{"port":"3000"}	\N	2026-04-13 21:50:44.88+03
30	info	SYSTEM	Sunucu başlatılıyor...	{"port":3000}	\N	2026-04-14 07:06:01.907+03
29	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-14 07:06:01.898+03
31	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-14 07:52:18.367+03
32	info	SYSTEM	Sunucu başlatılıyor...	{"port":"3000"}	\N	2026-04-14 07:52:18.368+03
33	info	SYSTEM	Sunucu başlatılıyor...	{"port":"3000"}	\N	2026-04-14 08:35:28.908+03
34	info	SYSTEM	PostgreSQL bağlantısı kuruldu (Prisma)	\N	\N	2026-04-14 08:35:28.907+03
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, key, value, label, updated_at) FROM stdin;
1	ticker_text	test1111111111	\N	2026-04-13 20:08:18.067+03
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password_hash, full_name, role, department, is_active, created_at) FROM stdin;
1	admin	$2a$10$eYTBDgmvZ.KBOGBoAg12BODrwndl0sedNEC0VIpw06deW/XqTQit6	Sistem Yöneticisi	admin	BT	t	2026-04-13 12:27:31.352+03
3	yusufkaraman	$2a$10$lEZJ5mmHla2LFoXktKdYj.acl8PHehd3xMvi9YH2js4JgwI68F7cS	Yusuf Karaman	personnel	\N	t	2026-04-13 19:06:20.627+03
4	aygerimbıkmaz	$2a$10$5PEyHPU6gPkUnxRmjt4dcezjVfnwa7wJap3c5pAmPII7EMYPDuHiC	Aygerim Bıkmaz	manager	\N	t	2026-04-13 19:06:56.054+03
2	burcuöktem	$2a$10$HPH9uhPDik5bTRyE6IikcupjqxRvEbM0GVJordFOILEj/EDSztTuy	Burcu Öktem	secretary	\N	t	2026-04-13 19:05:33.322+03
\.


--
-- Data for Name: visitors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.visitors (id, full_name, tc_no, phone, email, company_name, vehicle_plate, visitor_count, host_personnel_id, host_user_id, reason, notes, status, is_approved, is_screen_active, planned_time, arrival_time, checkout_time, created_by, created_at) FROM stdin;
1	Yusuf Karaman	12577108652	05533442766	YusufKaraman68@gmail.com	Simsoft	06 CKZ 235	3	3	3	İş Görüşmesi	test	left	t	f	\N	2026-04-13 20:16:24.552+03	2026-04-13 20:16:39.227+03	2	2026-04-13 20:15:47.469+03
2	Yusuf Karaman	\N	05533442766	YusufKaraman68@gmail.com	Simsoft	\N	2	4	4	Toplantı	test	left	t	f	\N	2026-04-13 20:36:27.533+03	2026-04-13 20:42:35.048+03	2	2026-04-13 20:35:46.63+03
3	Hilmi Difyeli	\N	\N	\N	Simsoft	\N	1	3	3	Teknik Destek	\N	left	t	f	\N	2026-04-13 21:30:08.269+03	2026-04-13 21:33:58.529+03	2	2026-04-13 21:30:00.03+03
4	Yusuf Karaman	12577108652	05533442766	YusufKaraman68@gmail.com	Simsoft	\N	1	4	4	İş Görüşmesi	\N	left	t	f	\N	2026-04-13 21:34:22.144+03	2026-04-13 23:30:59.853+03	2	2026-04-13 21:34:18.584+03
5	Yusuf Karaman	12577108652	05533442766	YusufKaraman68@gmail.com	Simsoft	34abc34	3	3	3	İş Görüşmesi	test	left	t	f	\N	2026-04-13 23:30:59.865+03	2026-04-13 23:32:03.724+03	3	2026-04-13 23:30:38.169+03
6	Selim Karaman	\N	\N	\N	Aselsan	\N	1	3	3	Danışma	test	left	t	f	\N	2026-04-13 23:32:03.73+03	2026-04-13 23:34:23.777+03	2	2026-04-13 23:31:57.367+03
7	Yusuf Karaman	12577108652	05533442766	YusufKaraman68@gmail.com	Aselsan	16ABC16	3	4	4	Teslimat	test	left	t	f	\N	2026-04-13 23:46:59.658+03	2026-04-13 23:48:33.523+03	2	2026-04-13 23:46:52.565+03
8	Hilmi Difyeli	\N	\N	\N	Simsoft	\N	1	4	4	Toplantı	\N	left	t	f	\N	2026-04-13 23:52:28.33+03	2026-04-13 23:52:37.698+03	2	2026-04-13 23:52:24.531+03
9	Yusuf Karaman	\N	\N	\N	Simsoft	\N	1	4	4	Toplantı	\N	left	t	f	\N	2026-04-14 00:50:10.018+03	2026-04-14 00:50:13.448+03	2	2026-04-14 00:50:06.407+03
10	Yusuf Karaman	\N	05533442766	YusufKaraman68@gmail.com	Simsoft	\N	1	4	4	Teknik Destek	\N	left	t	f	\N	2026-04-14 07:26:00.637+03	2026-04-14 08:00:08.644+03	2	2026-04-14 07:25:39.204+03
11	Selim Karaman	\N	\N	\N	\N	\N	1	3	3	Toplantı	\N	left	t	f	\N	2026-04-14 08:12:03.036+03	2026-04-14 08:12:28.56+03	2	2026-04-14 08:11:34.958+03
12	Selim Karaman	\N	\N	\N	Aselsan	\N	1	3	3	İş Görüşmesi	\N	left	t	f	\N	2026-04-14 08:14:34.036+03	2026-04-14 08:14:59.345+03	2	2026-04-14 08:13:53.462+03
13	Yusuf Karaman	\N	05533442766	YusufKaraman68@gmail.com	\N	\N	1	4	4	Teslimat	\N	left	t	f	\N	2026-04-14 08:33:04.84+03	2026-04-14 08:33:40.208+03	2	2026-04-14 08:33:01.699+03
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 64, true);


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointments_id_seq', 7, true);


--
-- Name: blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blacklist_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.companies_id_seq', 8, true);


--
-- Name: contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contents_id_seq', 23, true);


--
-- Name: personnel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personnel_id_seq', 4, true);


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.push_subscriptions_id_seq', 5, true);


--
-- Name: room_reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.room_reservations_id_seq', 2, true);


--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_id_seq', 1, true);


--
-- Name: screen_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.screen_logs_id_seq', 14, true);


--
-- Name: system_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_logs_id_seq', 34, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: visitors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.visitors_id_seq', 13, true);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: blacklist blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: contents contents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contents
    ADD CONSTRAINT contents_pkey PRIMARY KEY (id);


--
-- Name: personnel personnel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnel
    ADD CONSTRAINT personnel_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: room_reservations room_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_reservations
    ADD CONSTRAINT room_reservations_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: screen_logs screen_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.screen_logs
    ADD CONSTRAINT screen_logs_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: visitors visitors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visitors
    ADD CONSTRAINT visitors_pkey PRIMARY KEY (id);


--
-- Name: activity_logs_entity_type_entity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activity_logs_entity_type_entity_id_idx ON public.activity_logs USING btree (entity_type, entity_id);


--
-- Name: activity_logs_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activity_logs_user_id_created_at_idx ON public.activity_logs USING btree (user_id, created_at DESC);


--
-- Name: appointments_host_personnel_id_planned_time_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX appointments_host_personnel_id_planned_time_idx ON public.appointments USING btree (host_personnel_id, planned_time);


--
-- Name: appointments_host_user_id_planned_time_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX appointments_host_user_id_planned_time_idx ON public.appointments USING btree (host_user_id, planned_time);


--
-- Name: appointments_planned_time_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX appointments_planned_time_status_idx ON public.appointments USING btree (planned_time, status);


--
-- Name: companies_is_default_is_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX companies_is_default_is_active_idx ON public.companies USING btree (is_default, is_active);


--
-- Name: personnel_company_id_is_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personnel_company_id_is_active_idx ON public.personnel USING btree (company_id, is_active);


--
-- Name: personnel_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personnel_user_id_idx ON public.personnel USING btree (user_id);


--
-- Name: push_subscriptions_user_id_subscription_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX push_subscriptions_user_id_subscription_key ON public.push_subscriptions USING btree (user_id, subscription);


--
-- Name: screen_logs_start_time_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX screen_logs_start_time_idx ON public.screen_logs USING btree (start_time DESC);


--
-- Name: screen_logs_visitor_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX screen_logs_visitor_id_created_at_idx ON public.screen_logs USING btree (visitor_id, created_at DESC);


--
-- Name: system_settings_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX system_settings_key_key ON public.system_settings USING btree (key);


--
-- Name: users_role_is_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_role_is_active_idx ON public.users USING btree (role, is_active);


--
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- Name: visitors_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX visitors_created_at_idx ON public.visitors USING btree (created_at DESC);


--
-- Name: visitors_host_personnel_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX visitors_host_personnel_id_created_at_idx ON public.visitors USING btree (host_personnel_id, created_at DESC);


--
-- Name: visitors_host_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX visitors_host_user_id_created_at_idx ON public.visitors USING btree (host_user_id, created_at DESC);


--
-- Name: visitors_status_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX visitors_status_created_at_idx ON public.visitors USING btree (status, created_at DESC);


--
-- Name: visitors_tc_no_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX visitors_tc_no_idx ON public.visitors USING btree (tc_no);


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: appointments appointments_host_personnel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_host_personnel_id_fkey FOREIGN KEY (host_personnel_id) REFERENCES public.personnel(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: appointments appointments_host_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_host_user_id_fkey FOREIGN KEY (host_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: appointments appointments_visitor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_visitor_id_fkey FOREIGN KEY (visitor_id) REFERENCES public.visitors(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: blacklist blacklist_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contents contents_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contents
    ADD CONSTRAINT contents_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: personnel personnel_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnel
    ADD CONSTRAINT personnel_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: personnel personnel_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnel
    ADD CONSTRAINT personnel_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: room_reservations room_reservations_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_reservations
    ADD CONSTRAINT room_reservations_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: room_reservations room_reservations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_reservations
    ADD CONSTRAINT room_reservations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: visitors visitors_host_personnel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visitors
    ADD CONSTRAINT visitors_host_personnel_id_fkey FOREIGN KEY (host_personnel_id) REFERENCES public.personnel(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: visitors visitors_host_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visitors
    ADD CONSTRAINT visitors_host_user_id_fkey FOREIGN KEY (host_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict eb7qzUTimnXgfepXHrp0vGOa4BKWw18hWtz4HUKpg8h9IzMXckmuz3jD9eWJwzm

